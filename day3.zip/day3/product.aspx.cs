﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace day3
{
    public partial class product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            SqlDataAdapter da = new SqlDataAdapter("Select * from product", cnstr);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource=ds;
            GridView1.DataBind();
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            //SqlConnection cn = new SqlConnection(cnstr);
            SqlDataAdapter da = new SqlDataAdapter("usp_Add", cnstr);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@prodid", SqlDbType.SmallInt).Value = txtprodID.Text;
            da.SelectCommand.Parameters.AddWithValue("@prodname", SqlDbType.VarChar).Value = txtprodName.Text;
            da.SelectCommand.Parameters.AddWithValue("@price", SqlDbType.Money).Value = txtUP.Text;
            da.SelectCommand.Parameters.AddWithValue("@qty", SqlDbType.SmallInt).Value = txtQty.Text;
            DataSet ds = new DataSet();
            da.Fill(ds);

           Response.Write("Inserted successfully");
          
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            //SqlConnection cn = new SqlConnection(cnstr);
            SqlDataAdapter da = new SqlDataAdapter("usp_update", cnstr);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@prodid", SqlDbType.SmallInt).Value = txtprodID.Text;
            da.SelectCommand.Parameters.AddWithValue("@prodname", SqlDbType.VarChar).Value = txtprodName.Text;
            da.SelectCommand.Parameters.AddWithValue("@price", SqlDbType.Money).Value = txtUP.Text;
            da.SelectCommand.Parameters.AddWithValue("@qty", SqlDbType.SmallInt).Value = txtQty.Text;
            DataSet ds = new DataSet();
            da.Fill(ds);

            Response.Write("updated successfully");
          
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
           
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            //SqlConnection cn = new SqlConnection(cnstr);
            SqlDataAdapter da = new SqlDataAdapter("usp_delete", cnstr);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@prodid", SqlDbType.SmallInt).Value = txtprodID.Text;
            //da.SelectCommand.Parameters.AddWithValue("@prodname", SqlDbType.VarChar).Value = txtprodName.Text;
            //da.SelectCommand.Parameters.AddWithValue("@price", SqlDbType.Money).Value = txtUP.Text;
            //da.SelectCommand.Parameters.AddWithValue("@qty", SqlDbType.SmallInt).Value = txtQty.Text;
            DataSet ds = new DataSet();
            da.Fill(ds);

            Response.Write("deleted successfully");
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            string cnstr = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
            //SqlConnection cn = new SqlConnection(cnstr);
            SqlDataAdapter da = new SqlDataAdapter("usp_search", cnstr);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@prodid", SqlDbType.SmallInt).Value = txtprodID.Text;
            //da.SelectCommand.Parameters.AddWithValue("@prodname", SqlDbType.VarChar).Value = txtprodName.Text;
            //da.SelectCommand.Parameters.AddWithValue("@price", SqlDbType.Money).Value = txtUP.Text;
            //da.SelectCommand.Parameters.AddWithValue("@qty", SqlDbType.SmallInt).Value = txtQty.Text;
            DataSet ds = new DataSet();
            da.Fill(ds);

            Response.Write(" successfully searched");

        }
    }
}